# Voltage — iOS App (Capacitor)

This is a Capacitor project that wraps your existing Voltage web app (`www/index.html`) in a native
iOS shell, producing a real Xcode project you can build, run on a device, and submit to the App Store.

## What's already done
- Capacitor core + iOS platform installed and configured (`capacitor.config.ts`)
- Native Xcode project generated at `ios/App/App.xcodeproj`
- App name set to **Voltage**, bundle ID set to **com.watchvoltage.app** (change this — see below)
- Dark background (`#040912`) wired into the native splash screen and app background so there's no
  white flash on launch
- `@capacitor/status-bar` and `@capacitor/splash-screen` installed, and `index.html` calls them to
  dismiss the native splash and set a light (dark-content) status bar right when your own loader fades
- Uses Swift Package Manager (no CocoaPods/`pod install` step needed — Xcode resolves it automatically)

## What you still need to do

### 1. A Mac with Xcode
You can't build or submit an iOS app without macOS + Xcode (free from the Mac App Store). Everything
in this project is ready to hand to Xcode — nothing further can be done from here.

### 2. Add your media assets
Only `index.html` was available when this project was built, so `www/photos/` and `www/videos/` are
empty. Copy your actual `photos/` and `videos/` folders (and `manifest.json`) from your live site into
`www/`, replacing the empty placeholders, then run:
```
npx cap copy ios
```
to push them into the native project.

### 3. Set your own Bundle ID and Team
Open `ios/App/App.xcodeproj` in Xcode:
- Select the **App** target → **Signing & Capabilities**
- Pick your Apple Developer team
- Change the Bundle Identifier from `com.watchvoltage.app` to one you own (must be unique on the App
  Store), e.g. `com.yourcompany.voltage`
- Also update `appId` in `capacitor.config.ts` to match, then run `npx cap copy ios` again

### 4. App icon
Xcode's placeholder icon is currently blank. In `ios/App/App/Assets.xcassets/AppIcon.appiconset`,
add a 1024×1024 icon (your `voltage2025.png` logo on a solid background works well — App Store icons
can't have transparency). Easiest path: drag your 1024×1024 PNG into the AppIcon slot in Xcode's
asset catalog editor and let Xcode generate the rest, or use a tool like
[appicon.co](https://appicon.co) to generate the full set and drop it in.

### 5. Launch screen
There's a default `LaunchScreen.storyboard` under `ios/App/App/Base.lproj`. It's currently blank/white
— open it in Xcode's Interface Builder and set the background to `#040912` (or drop in your logo) so
the native launch screen matches the in-app splash before your own loader takes over.

### 6. Build & test
```
npm install        # if you haven't already
npx cap sync ios    # pulls in any config/plugin changes
open ios/App/App.xcodeproj
```
Then in Xcode, pick a simulator or your connected iPhone and hit Run (▶). Note: any features that
depend on Firebase / your backend will need whatever domains they call added to
`ios/App/App/Info.plist` under `NSAppTransportSecurity` if they're not HTTPS, though HTTPS calls need
no extra config.

### 7. Submit to the App Store
Once it looks right on device:
- Xcode menu → **Product → Archive**
- In the Organizer window, **Distribute App → App Store Connect → Upload**
- Finish setting up the listing (screenshots, description, privacy details) at
  [appstoreconnect.apple.com](https://appstoreconnect.apple.com)
- Requires an active Apple Developer Program membership ($99/year)

## Project structure
```
voltage-ios/
├── www/                    # your web app — this is what loads inside the native shell
│   ├── index.html
│   ├── photos/             # ← add your images here
│   └── videos/             # ← add your videos here
├── ios/
│   └── App/
│       ├── App.xcodeproj   # open this in Xcode
│       └── App/
│           ├── Info.plist
│           ├── Assets.xcassets   # app icon goes here
│           └── Base.lproj        # launch screen storyboard
├── capacitor.config.ts     # app id, name, splash/status bar config
└── package.json
```

## Making future changes
Whenever you edit `www/index.html` (or anything in `www/`), run `npx cap copy ios` to push the
changes into the Xcode project before rebuilding. If you add/remove Capacitor plugins, run
`npx cap sync ios` instead (it does a copy plus updates native dependencies).
