import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.watchvoltage.app',
  appName: 'Voltage',
  webDir: 'www',
  backgroundColor: '#040912',
  ios: {
    contentInset: 'always',
    backgroundColor: '#040912'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 800,
      backgroundColor: '#040912',
      showSpinner: false
    },
    StatusBar: {
      style: 'dark',
      overlaysWebView: true
    }
  }
};

export default config;
